var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["27731727-7837-4c54-a565-9c5e12aea03e","5a9a14dc-ec4c-428f-8a77-a71384392b06","d366df4a-015c-45b7-8b38-0841acdbdcc4"],"propsByKey":{"27731727-7837-4c54-a565-9c5e12aea03e":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"oqvLy4_8Eer.QBDtdXgJyebU4NYXw1u.","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/27731727-7837-4c54-a565-9c5e12aea03e.png"},"5a9a14dc-ec4c-428f-8a77-a71384392b06":{"name":"spike_bot_1","sourceUrl":"assets/api/v1/animation-library/gamelab/tTpE3X2vPx5y6euOte0owIR9YiTn5r5Z/category_robots/spike_bot.png","frameSize":{"x":116,"y":157},"frameCount":2,"looping":true,"frameDelay":2,"version":"tTpE3X2vPx5y6euOte0owIR9YiTn5r5Z","categories":["robots"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":232,"y":157},"rootRelativePath":"assets/api/v1/animation-library/gamelab/tTpE3X2vPx5y6euOte0owIR9YiTn5r5Z/category_robots/spike_bot.png"},"d366df4a-015c-45b7-8b38-0841acdbdcc4":{"name":"cuteanimals_dog_1","sourceUrl":"assets/api/v1/animation-library/gamelab/JjHnYpvn92NnC8Y6J5WrPFlNEEyGd8Po/category_animals/cuteanimals_dog.png","frameSize":{"x":275,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"JjHnYpvn92NnC8Y6J5WrPFlNEEyGd8Po","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":275,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/JjHnYpvn92NnC8Y6J5WrPFlNEEyGd8Po/category_animals/cuteanimals_dog.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var car1, car2, car3,car4;
var boundary1, boundary2;
var sam;

  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);
  
  sam = createSprite(20,190,13,13);
  sam.shapeColor = "green";
  
  car1 = createSprite(100,130,10,10);
  car1.shapeColor = "red";
  car2 = createSprite(215,130,10,10);
  car2.shapeColor = "red";
  car3 = createSprite(165,250,10,10);
  car3.shapeColor = "red";
  car4 = createSprite(270,250,10,10);
  car4.shapeColor = "red";
  
 
//Agrega velocidad para hacer que el auto se mueva.

car1.velocityY=-3;
car2.velocityY=+3;
car3.velocityY=-3;
car4.velocityY=+3;


function draw() {
   background("white");
  text("Lives: " + life,200,100);
  strokeWeight(0);
  fill("lightblue");
  rect(0,120,52,140);
  fill("yellow");
  rect(345,120,52,140);
  
// Crea la función bounceoff para hacer que el auto rebote en los límites.
car1.bounceOff(boundary1);
car1.bounceOff(boundary2);
car2.bounceOff(boundary1);
car2.bounceOff(boundary2);
car3.bounceOff(boundary1);
car3.bounceOff(boundary2);
car4.bounceOff(boundary1);
car4.bounceOff(boundary2);

//Agregar la condición para hacer que Sam se mueva de izquiera a derecha.

if (keyDown("left")){
  sam.x=sam.x-2;
}

if (keyDown("right")){
  sam.x=sam.x+2;
}

//Agregar la condición de reducir la vida de Sam si toca el carro.

if (sam.isTouching(car1) || sam.isTouching(car2) || sam.isTouching(car3) || sam.isTouching(car4))

{
  sam.x = 20;
  sam.y = 190;
  life = life + 1;
}
  
  sam.setAnimation("spike_bot_1");
   sam.scale = 0.18;
   car1.setAnimation("cuteanimals_dog_1");
   car1.scale = 0.10;
  car2.setAnimation("cuteanimals_dog_1");
   car2.scale = 0.10;
  car3.setAnimation("cuteanimals_dog_1");
   car3.scale = 0.10;
  car4.setAnimation("cuteanimals_dog_1");
   car4.scale = 0.110;
  
  
 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
